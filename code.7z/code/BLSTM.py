def get_cnn_network():
    '''
    get_feature = theano.function([origin_model.la./yers[0].input],origin_model.layers[11].get_output(train=False),allow_input_downcast=False)
    feature = get_feature(data)
    '''
    nbfilter = 16
    print 'configure cnn network'
    seq_model = set_cnn_model(4, 110)
    struct_model = set_cnn_model(6, 110)
    protein_model= set_cnn_model(20, 110)
    model = Sequential()
    model.add(Merge([seq_model,struct_model,protein_model], mode='concat', concat_axis=1))
    model.add(LSTM(2*nbfilter))
    model.add(Dense(nbfilter*3, activation='relu'))
    model.add(Dropout(0.5))
    return model
