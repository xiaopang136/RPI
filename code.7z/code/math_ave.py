ave_auc=auc_temp/10
ave_accu=accu_temp/10
ave_prec=prec_temp/10
ave_recall=recall_temp/10
ave_f1=f1_temp/10
ave_sen=sen_temp/10
ave_spec=spec_temp/10
ave_MCC=MCC_temp/10
file_P = open("test1446.txt", 'a')
file_P.write('The average:'+now_time+'\n'+'ave_auc:'+str(ave_auc)+'\t'+'ave_accu:'+str(ave_accu)+'\t'+'ave_prec:'+str(ave_prec)+ '\t'+'ave_recall:'+str(ave_recall) + '\t'+'ave_f1:'+str(ave_f1)+'\t'+'ave_sen:'+str(ave_sen)+ '\t'+'ave_spec:'+str(ave_spec)+'\t'+'ave_MCC:'+str(ave_MCC)+'\n')
file_P.close()