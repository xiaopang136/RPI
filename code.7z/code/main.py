# -*- coding: utf-8 -*-
import sys
import os
import numpy
import pdb
import xlrd
import gc
import psutil
import time
# import theano as th
# from memory_profiler import profile
os.environ['KERAS_BACKEND'] = 'theano'
import keras.backend as K
K.set_image_dim_ordering('th')

from keras.models import Sequential, model_from_config
from keras.layers.core import Dense, Dropout, Activation, Flatten, Merge
#from keras.layers import Input, merge, LSTM
from keras.layers.normalization import BatchNormalization
from keras.layers.advanced_activations import PReLU
from keras.utils import np_utils, generic_utils
from keras.optimizers import SGD, RMSprop, Adadelta, Adagrad, Adam
from keras.layers import normalization
from keras.layers.convolutional import Convolution2D, MaxPooling2D
from keras.layers import LSTM, Bidirectional 
from keras.layers.embeddings import Embedding
from keras.layers.convolutional import Convolution2D, MaxPooling2D,Convolution1D, MaxPooling1D,AveragePooling1D
from keras import regularizers
from keras import backend as K
from keras.callbacks import ModelCheckpoint, EarlyStopping,ReduceLROnPlateau
from keras.constraints import maxnorm
from keras.models import load_model
#from seya.layers.recurrent import Bidirectional
from sklearn import svm, grid_search
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.cross_validation import train_test_split
from sklearn.calibration import CalibratedClassifierCV
from sklearn.cross_validation import StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_curve, auc
from sklearn.externals import joblib
from sklearn.model_selection import KFold
from numpy import *
import numpy as np

from itertools import islice
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import random
import gzip
from sklearn import svm
from sklearn.svm import LinearSVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.decomposition import PCA
from sklearn import metrics
from sklearn.metrics import roc_auc_score,accuracy_score,precision_score,recall_score,f1_score

from sklearn.model_selection import train_test_split
from sklearn.grid_search import GridSearchCV
from scipy import sparse
from math import  sqrt
import theano
import subprocess as sp
import scipy.stats as stats

from keras import backend as K
import argparse
import re

import subprocess as sp
import os
import pdb
import re

def cut_text(text,lenth):
    textArr = re.findall('.{'+str(lenth)+'}', text)
    textArr.append(text[(len(textArr)*lenth):])
    return textArr
    
def padding_structure(stru, max_len, repkey = 'E'):
    seq_len = len(stru)
    if seq_len < max_len:
        gap_len = max_len -seq_len
        new_seq = stru + repkey * gap_len
    else:
        new_seq = stru[:max_len]
    return new_seq


def read_rnashape(structure_file):
    struct_dict = {}
    with gzip.open(structure_file, 'r') as fp:
        for line in fp:
            if line[0] == '>':
                name = line[:-1]
            else:
                strucure = line[:-1]
                struct_dict[name] = strucure
    return struct_dict


def get_bag_data_1_channel(data, max_len = 100):
    bags = []
    seqs = data["seq"]
    # labels = data["Y"]
    for seq in seqs:
        #pdb.set_trace()
        #bag_seqs = split_overlap_seq(seq)
        bag_seq = padding_sequence(seq, max_len = max_len)
        tri_fea = get_RNA_seq_concolutional_array(bag_seq)
        bags.append(tri_fea)
    return np.array(bags)

def read_seq_graphprot(seq_file):
    seq_list = []

    seq = ''
    with open(seq_file, 'r') as fp:
        for line in fp:
            if line[0] == '>':
                name = line[1:-1]
            else:
                seq = line[:-1].upper()
                seq = seq.replace('T', 'U')
                seq_list.append(seq)
    return seq_list

def read_data_file(posifile):
    RNAseq_data = dict()
    print posifile
    seqs = read_seq_graphprot(posifile)
    RNAseq_data["seq"] = seqs
    # print RNAseq_data["seq"]
    return RNAseq_data

def load_label_seq(seq_file):
    label_list = []
    seq = ''
    with open(seq_file, 'r') as fp:
        for line in fp:
            if line[0] == '>':
                name = line[1:-1]
                posi_label = name.split(';')[-1]
                label = posi_label.split(':')[-1]
                label_list.append(int(label))
    return np.array(label_list)

def set_cnn_model(input_dim, input_length):
    nbfilter = 16
    model = Sequential()
    model.add(Convolution1D(input_dim=input_dim,input_length=input_length,
                            nb_filter = nbfilter,
                            filter_length=10,
                            border_mode="valid",
                            subsample_length=1))
    model.add(Activation('relu'))
    model.add(MaxPooling1D(pool_length=3))
    model.add(Dropout(0.2))

    return model

def preprocess_labels(labels, encoder=None, categorical=True):
    if not encoder:
        encoder = LabelEncoder()
        encoder.fit(labels)
    y = encoder.transform(labels).astype(np.int32)
    if categorical:
        y = np_utils.to_categorical(y)
    return y, encoder

def split_training_validation(classes, validation_size = 0.1, shuffle = True):
    """split sampels based on balnace classes"""
    num_samples=len(classes)
    classes=np.array(classes)
    classes_unique=np.unique(classes)
    num_classes=len(classes_unique)
    indices=np.arange(num_samples)
    #indices_folds=np.zeros([num_samples],dtype=int)
    training_indice = []
    training_label = []
    validation_indice = []
    validation_label = []
    for cl in classes_unique:
        indices_cl=indices[classes==cl]
        num_samples_cl=len(indices_cl)

        # split this class into k parts
        if shuffle:
            random.shuffle(indices_cl) # in-place shuffle
        
        # module and residual
        num_samples_each_split=int(num_samples_cl*validation_size)
        res=num_samples_cl - num_samples_each_split
        
        training_indice = training_indice + [val for val in indices_cl[num_samples_each_split:]]
        training_label = training_label + [cl] * res
        
        validation_indice = validation_indice + [val for val in indices_cl[:num_samples_each_split]]
        validation_label = validation_label + [cl]*num_samples_each_split

    training_index = np.arange(len(training_label))
    random.shuffle(training_index)
    training_indice = np.array(training_indice)[training_index]
    training_label = np.array(training_label)[training_index]
    
    validation_index = np.arange(len(validation_label))
    random.shuffle(validation_index)
    validation_indice = np.array(validation_indice)[validation_index]
    validation_label = np.array(validation_label)[validation_index]
    return training_indice, training_label, validation_indice, validation_label

def run_network_new(model, total_hid, training, y, t ,validation, val_y, batch_size=16, nb_epoch= 100):
    h=t
    model.add(Dense(2, input_shape=(total_hid,)))
    model.add(Activation('sigmoid'))
    model.compile(loss='categorical_crossentropy', optimizer='rmsprop')
    earlystopper = EarlyStopping(monitor='val_loss', patience= 10, verbose=1,mode='auto')
    reducelr = ReduceLROnPlateau(monitor='val_loss', factor=0.1, patience= 1, verbose=1, mode='auto',cooldown=0, min_lr=0)
    sovemodel = ModelCheckpoint('./model/model_file_'+str(h)+'.pkl', monitor='val_loss', verbose=1, save_best_only=True, mode='auto')
    model.fit(training, y, batch_size=batch_size, nb_epoch=nb_epoch, verbose=1,validation_data=(validation, val_y), callbacks=[earlystopper,reducelr,sovemodel],shuffle=True)
    return model

def read_pro_file(posifile):
    RNAseq_data = dict()
    # print posifile
    seqs = read_pro_graphprot(posifile)
    RNAseq_data["seq"] = seqs
    # print RNAseq_data["seq"]
    return RNAseq_data

def read_pro_graphprot(seq_file):
    seq_list = []

    seq = ''
    with open(seq_file, 'r') as fp:
        for line in fp:
            if line[0] == '>':
                name = line[1:-1]
            else:
                seq = line[:-1].upper()
                seq_list.append(seq)
    return seq_list


def get_pro_data_1_channel(data, max_len=100):
    bags = []
    seqs = data["seq"]
    # labels = data["Y"]
    for seq in seqs:
        # pdb.set_trace()
        # bag_seqs = split_overlap_seq(seq)
        bag_seq = padding_pro(seq, max_len=max_len)
        # print bag_seq
        tri_fea = get_pro_concolutional_array(bag_seq)
        bags.append(tri_fea)
    return np.array(bags)


def padding_pro(seq, max_len, repkey='X'):
    seq_len = len(seq)
    if seq_len < max_len:
        gap_len = max_len - seq_len
        new_seq = seq + repkey * gap_len
    else:
        new_seq = seq[:max_len]
    return new_seq


def get_pro_concolutional_array(seq, motif_len=10):
    alpha = 'ARNDCQEGHILKMFPSTWYV'
    # for seq in seqs:
    # for key, seq in seqs.iteritems():
    half_len = motif_len / 2
    row = (len(seq) + half_len * 2)
    new_array = np.zeros((row, 20))
    for i in range(half_len):
        new_array[i] = np.array([0.05] * 20)

    for i in range(row - half_len, row):
        new_array[i] = np.array([0.05] * 20)

    # pdb.set_trace()
    for i, val in enumerate(seq):
        i = i + motif_len/2
        if val not in 'ARNDCQEGHILKMFPSTWYV':
            new_array[i] = np.array([0.05] * 20)
            continue
        try:
            index = alpha.index(val)
            new_array[i][index] = 1
        except:
            pdb.set_trace()
    return new_array

def get_tiain_data(posi, max_size=100, channel = 1):

    # RNA seq
    data = read_data_file(posi)
    if channel == 1:
        train_bags = get_bag_data_1_channel(data, max_size)
    # RNA structure  
    path = os.path.dirname(posi)
    if len(path):
        path = './'
    seq_onehot,structure = read_structure(posi , path , max_size)

    # protein
    data = read_pro_file("home/aistudio/data/1807/dataP.fa")
    protein_array = get_pro_data_1_channel(data, max_size)

    # label
    Y=load_label_seq(posi)
    return train_bags,protein_array,Y



def calculate_performace(test_num, pred_y, labels):
    tp = 0
    fp = 0
    tn = 0
    fn = 0
    for index in range(test_num):
        if labels[index] == 1:
            if labels[index] == pred_y[index]:
                tp = tp + 1
            else:
                fn = fn + 1
        else:
            if labels[index] == pred_y[index]:
                tn = tn + 1
            else:
                fp = fp + 1

    acc = float(tp + tn) / test_num
    sensitivity = float(tp) / (tp + fn)
    specificity = float(tn) / (tn + fp)
    MCC = float(tp * tn - fp * fn) / (np.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn)))
    return sensitivity, specificity, MCC

# @profile(precision=4,stream=open('memory.log','w+'))
def train_ideeps(posi,model_file,outfile,channel,max_size,batch_size=16, nb_epoch = 100):
    rna_seq_array,protein,label_Y = get_tiain_data(posi=posi,max_size=max_size)
    # print len(rna_seq_array[0]),len(rna_str_array[0]),len(protein[0])
    print label_Y
    kf = KFold(n_splits=10,shuffle=True)

    t=0

    auc_temp = 0
    accu_temp = 0
    prec_temp = 0
    recall_temp = 0
    f1_temp = 0
    sen_temp = 0
    spec_temp = 0
    MCC_temp = 0
    for train_index, test_index in kf.split(label_Y):
        print 'The model training '+ str(t) +' times'
        print 'train_index', train_index, 'test_index', test_index
        seq_hid = 16
        struct_hid = 16
        protein_hid = 16

        train_Y = label_Y[train_index]
        
        training_indice, training_label, validation_indice, validation_label = split_training_validation(train_Y)
        
        cnn_train  = []
        cnn_validation = []

        seq_data = rna_seq_array[train_index]

        seq_train = seq_data[training_indice]
        seq_validation = seq_data[validation_indice]

        struct_data = rna_str_array[train_index]

        struct_train = struct_data[training_indice]
        struct_validation = struct_data[validation_indice]

        protein_data = protein[train_index]

        protein_train = protein_data[training_indice]
        protein_validation = protein_data[validation_indice]

        cnn_train.append(seq_train)
        cnn_train.append(struct_train)
        cnn_train.append(protein_train)

        cnn_validation.append(seq_validation)
        cnn_validation.append(struct_validation)
        cnn_validation.append(protein_validation)

        seq_net = get_cnn_network()

        y, encoder = preprocess_labels(training_label)
        val_y, encoder = preprocess_labels(validation_label, encoder = encoder)


        total_hid = seq_hid  + seq_hid + protein_hid
        total_hid = seq_hid + protein_hid
        model = run_network_new(seq_net, total_hid, cnn_train, y, t=t,validation = cnn_validation, val_y = val_y, batch_size=batch_size, nb_epoch = nb_epoch)  

        
        print 'The model test '+ str(t) +' times'

        data = dict()
        tmp = []
        tmp.append(rna_seq_array[test_index])
        tmp.append(rna_str_array[test_index])
        tmp.append(protein[test_index])
        data["seq"] = tmp

        ture_Y = label_Y[test_index]
        print list(ture_Y)
        testing = data["seq"]
        # #it includes one-hot encoding sequence and structure
        model = load_model(os.path.join(model_file,'model_file_'+str(t)+'.pkl'))
        
        pred = model.predict_proba(testing)[:,1]
        auc2 = roc_auc_score(ture_Y,pred)
        pred_labal= model.predict_classes(testing)
        print pred_labal

        fpr, tpr, thresholds = roc_curve(ture_Y, pred)
        tprs.append(interp(mean_fpr, fpr, tpr))
        tprs[-1][0] = 0.0

        roc_auc = auc(fpr, tpr)
        aucs.append(roc_auc)
        plt.plot(fpr, tpr, lw=1, alpha=0.3,
        label='ROC fold %d (AUC = %0.3f)' % (t, roc_auc))

        
        if len(ture_Y)==len(pred_labal) and len(test_index)==len(pred_labal):
            index = np.arange(0,len(ture_Y))
            no_labal = index[ture_Y != pred_labal]
            
            file = open('labal.txt','a')
            file.write('\n')
            file.close()
            
            for i in no_labal:
                file = open("labal.txt", 'a')
                file.write(str(test_index[i]) + '\n')
                file.close()
        
        print "Test AUC: ", auc2
        
        accu = accuracy_score(ture_Y,pred_labal)
        print "Test ACCU: ", accu

        prec = precision_score(ture_Y,pred_labal)
        print "Test PREC: ", prec

        recall = metrics.recall_score(ture_Y, pred_labal)
        print "Test RECALL: ", recall
        
        f1= metrics.f1_score(ture_Y, pred_labal)
        print "Test F1: ", f1

        sen, spec, MCC = calculate_performace(len(ture_Y), pred_labal,ture_Y)
        print 'Test sen:',sen
        print 'Test spec:',spec
        print 'Test MCC:',MCC
        now_time = time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(time.time()))
        file_P = open("your.txt", 'a')
        file_P.write('The model training '+ str(t) +' times:'+now_time+'\n'+'auc:'+str(auc2)+'\t'+'accu:'+str(accu)+'\t'+'prec:'+str(prec)+ '\t'+'recall:'+str(recall)+'\t'+ 'f1:'+str(f1)+'\t'+'sen:'+str(sen)+'\t'+'spec:'+str(spec)+'\t'+'MCC:'+str(MCC)+'\n')
        file_P.close()

        auc_temp = auc2 + auc_temp
        accu_temp = accu + accu_temp
        prec_temp = prec + prec_temp
        recall_temp = recall + recall_temp
        f1_temp = f1 + f1_temp
        sen_temp = sen + sen_temp
        spec_temp = spec + spec_temp
        MCC_temp = MCC + MCC_temp
        fw = open(outfile+'_'+str(t), 'w')
        myprob = "\n".join(map(str, pred))
        fw.write(myprob)
        fw.close()
        t=t+1

def run_ideepe(parser):
    posi = parser.in_file_R
    model_type = parser.model_type
    ensemble = parser.ensemble
    out_file = parser.out_file
    train = parser.train
    model_file = parser.model_file
    predict = parser.predict
    motif = parser.motif
    motif_outdir = parser.motif_dir
    max_size = parser.maxsize
    channel = parser.channel
    # local = parser.local
    # window_size = parser.window_size
    ensemble = parser.ensemble
    batch_size = parser.batch_size
    n_epochs = parser.n_epochs
    num_filters = parser.num_filters
    testfile = parser.testfile
    if not os.path.exists(model_file):
        os.makedirs(model_file)
    if predict:
        train = False
    if train:
        train_ideeps(posi,model_file,out_file,channel,max_size=max_size,batch_size= batch_size, nb_epoch = n_epochs)

def parse_arguments(parser):
    parser.add_argument('--in_file_R', type=str, metavar='<postive_sequecne_file>', help='The fasta file of positive training samples')
    parser.add_argument('--model_type', type=str, default='CNN', help='it supports the following deep network models: CNN, CNN-LSTM, ResNet and DenseNet, default model is CNN')
    parser.add_argument('--out_file', type=str, default='prediction.txt', help='The output file used to store the prediction probability of the testing sequences')
    parser.add_argument('--motif', type=bool, default=False, help='It is used to identify binding motifs from sequences.')
    parser.add_argument('--motif_dir', type=str, default='motifs', help='The dir used to store the prediction binding motifs.')
    parser.add_argument('--train', type=bool, default=True, help='The path to the Pickled file containing durations between visits of patients. If you are not using duration information, do not use this option')
    parser.add_argument('--model_file', type=str, default='model', help='The file to save model parameters. Use this option if you want to train on your sequences or predict for your sequences')
    parser.add_argument('--predict', type=bool, default=False,  help='Predicting the RNA-protein binding sites for your input sequences, if using train, then it will be False')
    parser.add_argument('--testfile', type=str, default='',  help='the test fast file for sequences you want to predict for, you need specify it when using predict')
    parser.add_argument('--maxsize', type=int, default=100, help='For global sequences, you need specify the maxmimum size to padding all sequences, it is only for global CNNs (default value: 161)')
    parser.add_argument('--channel', type=int, default=1, help='The number of channels for breaking the entire RNA sequences to multiple subsequences, you can specify this value only for local CNNs (default value: 7)')
    parser.add_argument('--ensemble', type=bool, default=True, help='It runs the ensembling of local and global CNNs, you need specify the maxsize (default 501) for global CNNs and window_size (default: 101) for local CNNs')
    parser.add_argument('--batch_size', type=int, default=16, help='The size of a single mini-batch (default value: 100)')
    parser.add_argument('--num_filters', type=int, default=16, help='The number of filters for CNNs (default value: 16)')
    parser.add_argument('--n_epochs', type=int, default=100, help='The number of training epochs (default value: 3)')
    args = parser.parse_args()
    return args

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    args = parse_arguments(parser)
    print args
    run_ideepe(args)