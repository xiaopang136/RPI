def set_cnn_model(input_dim, input_length):
nbfilter = 16
model = Sequential()
model.add(Convolution1D(input_dim=input_dim,input_length=input_length,
                        nb_filter = nbfilter,
                        filter_length=10,
                        border_mode="valid",
                        subsample_length=1))
model.add(Activation('relu'))
model.add(MaxPooling1D(pool_length=3))
model.add(Dropout(0.2))

return model